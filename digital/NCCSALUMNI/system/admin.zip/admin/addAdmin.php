<?php

include('C:\xampp\htdocs\digital\NCCSALUMNI\system\MainClass.php');
$mainclassobj=new MainClass;

$Fullname=$_POST['adminfn'];
$Username=$_POST['adminuname'];
$Password=$_POST['adminpswd'];
$CFPassword=$_POST['cfpswd'];

$mainclassobj->adminRegistration($Fullname,$Username,$Password,$CFPassword);
header("location:addAdmin.html");
/*
else{
	header("location:adminindex.html");
}*/
?>
